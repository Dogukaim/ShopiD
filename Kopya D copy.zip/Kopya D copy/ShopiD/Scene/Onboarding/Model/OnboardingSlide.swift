//
//  OnboardingSlide.swift
//  ShopiD
//
//  Created by Dogukaim on 1.09.2023.
//

import UIKit

struct OnboardingSlide {
    
    let image: UIImage
    let title: String
    let subTitle: String
}
