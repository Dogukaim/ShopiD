//
//  MidCollectionController.swift
//  ShopiD
//
//  Created by Dogukaim on 7.09.2023.
//

import UIKit

class MidCollectionController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    


}
