//
//  ProfileController.swift
//  ShopiD
//
//  Created by Dogukaim on 6.09.2023.
//

import UIKit

class ProfileController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    

 

}
