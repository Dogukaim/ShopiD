//
//  FavoriteCell.swift
//  ShopiD
//
//  Created by Dogukaim on 12.09.2023.
//

import UIKit

class FavoriteCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
