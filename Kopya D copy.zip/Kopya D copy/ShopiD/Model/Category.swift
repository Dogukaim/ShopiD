//
//  Category.swift
//  ShopiD
//
//  Created by Dogukaim on 8.09.2023.
//

import Foundation

typealias Categories = [String]
